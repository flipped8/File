 <center>
     <h1>XXX</h1>
     <div>
         <span>
             <img src="assets/phone-solid.svg" width="18px">
             180XXXXXXXX
         </span>
         ·
         <span>
             <img src="assets/envelope-solid.svg" width="18px">
             zhengyc101@163.com
         </span>
         ·
         <span>
             <img src="assets/github-brands.svg" width="18px">
             <a href="https://github.com/CyC2018">CyC2018</a>
         </span>
         ·
         <span>
             <img src="assets/rss-solid.svg" width="18px">
             <a href="#">My Blog</a>
         </span>
     </div>
 </center>

 ## <img src="assets/info-circle-solid.svg" width="30px"> 个人信息 

 - 男，1994 年出生
 - 求职意向：Java 研发工程师
 - 工作经验：0 年（校招可不填）
 - 期望薪资：0k（校招可不填）

## <img src="assets/graduation-cap-solid.svg" width="30px"> 教育经历

- 硕士，XXXX大学，计算机科学与技术专业，2016.9~2019.7
- 学士，XXXX大学，软件工程专业，2012.9~2016.7
- 绩点：***，年级前 100%
- 通过了 CET4/6 英语等级考试

## <img src="assets/briefcase-solid.svg" width="30px"> 工作经历

- **XXXX 公司，XXXX 部门，XXXX 工程师，2010.1~2010.9**

   负责 XXX

## <img src="assets/project-diagram-solid.svg" width="30px"> 项目经历

- **XXXX 项目**

  *使用到的技术*

  使用一两句话描述项目的主要功能，然后介绍自己在项目中的角色，解决了什么问题，使用什么方式解决，比别人的方法相比有什么优势（尽量用数据来说明）。

## <img src="assets/tools-solid.svg" width="30px"> 技能清单

- ★★★ Java
- ★★☆ C++、Python
- ★★★ MySQL
- ★★★ Redis
- ★★☆ Spring
- ★☆☆ RabbitMQ、ZooKeeper
- ★★☆ JavaScript